# CRNN для чтения номера (SmartParking AI, часть 3)

Файлы: crnn_best.pt (веса), crnn_ocr.py (модель + предобработка + декодер).
Нужно: python 3.9+, torch, numpy, pillow.

    from crnn_ocr import CRNNReader
    reader = CRNNReader("crnn_best.pt")          # cuda, если есть, иначе cpu
    reader.read("crop.png")                      # 'A123BC77'
    reader.read_with_conf("crop.png")            # ('A123BC77', 0.98)
    reader.read_batch([img1, img2])              # список строк
    reader.read(cv2_crop, bgr=True)              # если кроп из cv2 (порядок BGR)

Вход: УЖЕ вырезанный номер (рамку ищет часть 2). Алфавит: 0123456789ABEKMHOPCTYX. Выход: латиница без пробелов.
Метрики val: CER 0.0059, Exact Match 0.9890.
Метрики test: CER 0.0078, Exact Match 0.9821.
